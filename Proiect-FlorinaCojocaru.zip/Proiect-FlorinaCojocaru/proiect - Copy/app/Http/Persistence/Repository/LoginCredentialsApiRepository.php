<?php

namespace App\Http\Persistence\Repository;

use App\Http\Domain\Repository\LoginCredentialsApiRepositoryContract;
use Illuminate\Support\Facades\DB;

class LoginCredentialsApiRepository implements LoginCredentialsApiRepositoryContract
{
    const TABLE = 'login_credentials_api';

    public function get(int $userId): array
    {
        return DB::table(self::TABLE)
            ->where('user_id', $userId)
            ->get()
            ->toArray();
    }

    public function show(array $values)
    {
        return DB::table(self::TABLE)
            ->where('id', $values['id'])
            ->where('user_id', $values['user_id'])
            ->first();
    }

    public function store(array $values): bool
    {
        return DB::table(self::TABLE)->insert($values);
    }

    public function update(array $values): int
    {
        return DB::table(self::TABLE)
            ->where('id', $values['id'])
            ->where('user_id', $values['user_id'])
            ->update($values);
    }

    public function delete(array $values): int
    {
        return DB::table(self::TABLE)
            ->where('id', $values['id'])
            ->where('user_id', $values['user_id'])
            ->delete();
    }
}
