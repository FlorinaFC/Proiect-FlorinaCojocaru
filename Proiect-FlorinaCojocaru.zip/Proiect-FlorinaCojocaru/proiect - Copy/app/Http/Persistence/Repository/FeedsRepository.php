<?php

namespace App\Http\Persistence\Repository;
use App\Http\Domain\Repository\FeedsRepositoryContract;
use Illuminate\Support\Facades\DB;

class FeedsRepository implements FeedsRepositoryContract
{
    public function getAll()
    {
        return DB::table('feeds')->get()->toArray();
    }
}