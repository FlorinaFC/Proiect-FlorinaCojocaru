<?php

namespace App\Http\Persistence\Repository;

use App\Http\Domain\Repository\LoginResponseApiRepositoryContract;
use Illuminate\Support\Facades\DB;

class LoginResponseApiRepository implements LoginResponseApiRepositoryContract
{

    const TABLE = 'login_response_api';

    public function show(array $values)
    {
        return DB::table(self::TABLE)
            ->where('user_id', $values['user_id'])
            ->first();
    }

    public function upsert(array $values): bool
    {
        return DB::table(self::TABLE)
            ->updateOrInsert(
                ['user_id' => $values['user_id']],
                [
                    'login_credentials_api_id' => $values['login_credentials_api_id'],
                    'access-token'              => $values['access-token'],
                    'client'                    => $values['client'],
                    'uid'                       => $values['uid'],
                    'token-type'                => $values['token-type']
                ]
            );
    }
}
