<?php

namespace App\Http\Domain\Repository;

interface LoginResponseApiRepositoryContract
{
    public function show(array $values);

    //an upsert is a database operation that will update an existing row if a specified value
    //already exists in a table, and insert a new row if the specified value doesn't already exist
    public function upsert(array $values);

}