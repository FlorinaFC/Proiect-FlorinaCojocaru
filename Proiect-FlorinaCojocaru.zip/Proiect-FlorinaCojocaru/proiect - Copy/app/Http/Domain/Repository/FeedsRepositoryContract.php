<?php

namespace App\Http\Domain\Repository;

interface FeedsRepositoryContract
{
    public function getAll();
}