<?php

namespace App\Http\Domain\Repository;

interface LoginCredentialsApiRepositoryContract
{
    public function get(int $userId);

    public function show(array $values);

    public function store(array $values);

    public function update(array $values);

    public function delete(array $values);
}
