<?php

namespace App\Http\Domain\Service\ApiAuth;

use App\Http\Domain\Repository\LoginCredentialsApiRepositoryContract;
use App\Http\Domain\Repository\LoginResponseApiRepositoryContract;
use Illuminate\Support\Facades\Log;

class LoginService
{
    const API_LOGIN_URL = '';
    
    const API_LOGIN_EMAIL = "";

    const API_LOGIN_PASS = "";

    const API_USER_KEY = '';

    protected LoginResponseApiRepositoryContract $loginResponseApiRepo;

    public function __construct(
        LoginResponseApiRepositoryContract $loginResponseApiRepo
    ) {
        $this->loginResponseApiRepo = $loginResponseApiRepo;
    }

    public function execute(): bool
    {
       //login to get the headers

       $curl = curl_init();
       curl_setopt_array($curl, array(
           CURLOPT_URL => self::API_LOGIN_URL,
           CURLOPT_RETURNTRANSFER => true,
           CURLOPT_ENCODING => '',
           CURLOPT_MAXREDIRS => 10,
           CURLOPT_TIMEOUT => 0,
           CURLOPT_FOLLOWLOCATION => true,
           CURLOPT_CUSTOMREQUEST => 'POST',
           CURLOPT_POSTFIELDS =>'{
             "user": {
               "email": "' . self::API_LOGIN_EMAIL . '",
               "password": "' . self::API_LOGIN_PASS . '"
             }
           }',
           CURLOPT_HTTPHEADER => array(
               'user-key: ' . self::API_USER_KEY,
               'Content-Type: application/json'
           ),
       ));

       curl_setopt( $curl , CURLOPT_HEADER , true );
       $response = curl_exec($curl);
       if(curl_error($curl)) {
           //here add error
           echo 'curl error is -' . curl_error($curl);
       }

       $headerSize = curl_getinfo( $curl , CURLINFO_HEADER_SIZE );
       $headerStr = substr( $response , 0 , $headerSize );

       // convert headers to array
       $headers = $this->headersToArray( $headerStr );
       curl_close($curl);


       //here add error
       return $this->loginResponseApiRepo->upsert(
           [
               'user_id'                   => 1,
               'login_credentials_api_id'  => 5,
               'access-token'              => $headers['access-token'],
               'client'                    => $headers['client'],
               'uid'                       => self::API_LOGIN_EMAIL,
               'token-type'                => 'Bearer'
           ]
       );
    }

    private function headersToArray(string $str): array
    {
        $headers = [];
        $headersTmpArray = explode( "\r\n" , $str );
        for ( $i = 0 ; $i < count( $headersTmpArray ) ; ++$i ) {
            // we dont care about the two \r\n lines at the end of the headers
            if ( strlen( $headersTmpArray[$i] ) > 0 ) {
                // the headers start with HTTP status codes, which do not contain a colon so we can filter them out too
                if ( strpos( $headersTmpArray[$i] , ":" ) ) {
                    $headerName = substr( $headersTmpArray[$i] , 0 , strpos( $headersTmpArray[$i] , ":" ) );
                    $headerValue = substr( $headersTmpArray[$i] , strpos( $headersTmpArray[$i] , ":" )+1 );
                    $headers[$headerName] = $headerValue;
                }
            }
        }
        return $headers;
    }


}
