<?php

namespace App\Http\Domain\Service\DataSync;

use App\Http\Domain\Service\ApiAuth\LoginService;
use App\Http\Domain\Service\ApiAuth\TPerformant;

class DataSyncService
{


    protected LoginService $loginService;
    protected RequestDataService $requestDataService;
        public function __construct(
            LoginService $loginService,
            RequestDataService $requestDataService

    ) {
        $this->loginService = $loginService;
        $this->requestDataService = $requestDataService;

    }

    public function execute()
    {
        //login and store the response
        $this->loginService->execute();
        
        //make API requests using response from table login_response_api

        $this->requestDataService->execute();
        //insert into db the data returned from API
        return true;
    }
}
