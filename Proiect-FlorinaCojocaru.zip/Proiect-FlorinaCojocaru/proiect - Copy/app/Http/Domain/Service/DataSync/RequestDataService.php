<?php

namespace App\Http\Domain\Service\DataSync;

use App\Http\Domain\Repository\FeedsRepositoryContract;
use App\Http\Domain\Repository\LoginResponseApiRepositoryContract;
use DateTime;

class RequestDataService
{
    protected LoginResponseApiRepositoryContract $loginResponseApiRepo;
    protected FeedsRepositoryContract $feedsRepo;

    public function __construct(
        LoginResponseApiRepositoryContract $loginResponseApiRepo,
        FeedsRepositoryContract $feedsRepo,
    ) {
        $this->loginResponseApiRepo = $loginResponseApiRepo;
        $this->feedsRepo = $feedsRepo;
    }

    public function execute()
    {
        //get credentials din LoginResponseApi
        $user_credentials = $this->loginResponseApiRepo->show(['user_id' => 1]);
        // dd($user_credentials);

        //get all the URL from feeds
        $allURL = $this->feedsRepo->getAll();
        // dd($allURL);


        //trec prin toate url-urile din feeds folosind curl si salvand raspunsurile lor
        foreach($allURL as $item)
        {
            $this->getResponse($item->feed_url, (array)$user_credentials);
        }

    }

    protected function getResponse(string $url, $user_credentials)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_ENCODING        => '',
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   => 'GET',
            CURLOPT_HTTPHEADER      => [
                'access-token: ' . $user_credentials['access-token'],
                'uid: @gmail.com',
                'client: ' . $user_credentials['client'],
                'uid: @gmail.com',
                'token-type: Bearer'
            ],
        ]);

        $response = curl_exec($curl);
        //here add error
        curl_close($curl);
        dd($response);

    }

    
}