<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Mail;

use App\Mail\ContactFormMail;

class HomeController extends Controller
{
	public function index()
    {
        return view('contact');
    }

    public function favorite()
    {
        return view('favorite');
    }

    public function compara()
    {
        return view('compara');
    }

    public function politicaDeConfidentialitate()
    {
        return view('politicaDeConfidentialitate');
    }

    public function termeniSiConditii()
    {
        return view('termeniSiConditii');
    }

    public function politicaDeUtilizareCookie()
    {
        return view('politicaDeUtilizareCookie');
    }
}