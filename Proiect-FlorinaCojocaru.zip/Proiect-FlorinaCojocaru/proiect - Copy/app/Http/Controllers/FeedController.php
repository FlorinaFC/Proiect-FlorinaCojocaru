<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateFeedRequest;
use App\Models\Feed;
use Illuminate\Http\Request;

class FeedController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $feeds = Feed::all();

        return view('feed.index', compact('feeds'));    
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('feed.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CreateFeedRequest $request)
    {
        Feed::create($request->validated());
        return redirect()->route('feeds.create')->with('success', 'Feed adăugat cu succes!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $feed = Feed::findOrFail($id);
        return view('feed.show', compact('feed'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CreateFeedRequest $request, string $id)
    {
        $feed = Feed::findOrFail($id);

        $feed->update($request->validated());

        return redirect()->route('feeds.show', $feed->id)->with('success', 'Feed modificat cu succes!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $feed = Feed::findOrFail($id);

        $feed->delete();

        return redirect()->route('feeds.index')->with('success', 'Feed șters cu succes!');
    }
}
