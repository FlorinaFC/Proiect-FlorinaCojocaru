<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(
            'App\Http\Domain\Repository\LoginCredentialsApiRepositoryContract',
            'App\Http\Persistence\Repository\LoginCredentialsApiRepository'
        );

        $this->app->bind(
            'App\Http\Domain\Repository\LoginResponseApiRepositoryContract',
            'App\Http\Persistence\Repository\LoginResponseApiRepository'
        );

        $this->app->bind(
            'App\Http\Domain\Repository\FeedsRepositoryContract',
            'App\Http\Persistence\Repository\FeedsRepository'
        );
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
