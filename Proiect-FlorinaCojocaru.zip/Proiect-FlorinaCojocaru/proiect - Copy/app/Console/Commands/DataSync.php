<?php

namespace App\Console\Commands;

use App\Http\Domain\Service\DataSync\DataSyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class DataSync extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:data-sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch data from API by status';

    /**
     * Execute the console command.
     */
    public function handle(
        DataSyncService $dataSyncService
    ) {
        $dataSyncService->execute();
    }
}
