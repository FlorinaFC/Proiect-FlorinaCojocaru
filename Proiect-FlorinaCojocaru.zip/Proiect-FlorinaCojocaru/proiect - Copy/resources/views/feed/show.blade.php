@extends('layouts.app')
@section('content')
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
        {{ __($feed->feed_name) }}
    </h2>
    @if (session()->has('success'))
        <div class="text-center py-3 bg-green-400 rounded-sm">{{ session('success') }}</div>
    @endif
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <form method="post" action="{{ route('feeds.update', $feed->id) }}" class="mt-6 space-y-6">
                        @csrf
                        @method('put')
                        <div class="mt-3">
                            <x-input-label for="feed_name" :value="__('Nume feed')" />
                            <x-text-input id="feed_name" name="feed_name" type="text" class="mt-1 block w-full"
                                :value="$feed->feed_name" />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_name')" />
                        </div>

                        <div class="mt-3">
                            <x-input-label for="feed_url" :value="__('URL Feed')" />
                            <x-text-input id="feed_url" name="feed_url" type="text" class="mt-1 block w-full"
                                :value="$feed->feed_url" />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_url')" />
                        </div>

                        <div class="mt-3">
                            <x-input-label for="feed_update" :value="__('Update Feed')" />
                            <x-text-input id="feed_update" name="feed_update" type="dateTime" class="mt-1 block w-full"
                                :value="$feed->feed_update" />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_update')" />
                        </div>

                        <x-primary-button>{{ __('Modifică!') }}</x-primary-button>
                    </form>
                    <form method="post" action="{{ route('feeds.update', $feed->id) }}" class="mt-6 space-y-6">
                        @csrf
                        @method('delete')
                        <x-secondary-button>{{ __('Șterge!') }}</x-secondary-button>
                    </form>


                </div>
            </div>
        </div>
    </div>
@endsection
