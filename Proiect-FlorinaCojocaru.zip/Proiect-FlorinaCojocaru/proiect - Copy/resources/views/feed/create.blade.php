@extends('layouts.app')
@section('content')
    {{-- <x-app-layout> --}}
    <x-slot name="header">

        <p class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Adaugă un nou Feed') }}
        </p>
    </x-slot>

    <div class="py-12">
        @if (session()->has('success'))
            <div class="text-center py-3 bg-green-400 rounded-sm">{{ session('success') }}</div>
        @endif
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <form method="post" action="{{ route('feeds.store') }}" class="mt-6 space-y-6">
                        @csrf
                        <div class="mt-3">
                            <x-input-label for="feed_name" :value="__('Nume Feed')" />
                            <x-text-input id="feed_name" name="feed_name" type="text" class="mt-1 block w-full"
                                :value="old('feed_name')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_name')" />
                        </div>

                        <div class="mt-3">
                            <x-input-label for="feed_url" :value="__('URL Feed')" />
                            <x-text-input id="feed_url" name="feed_url" type="text" class="mt-1 block w-full"
                                :value="old('feed_url')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_url')" />
                        </div>

                        <div class="mt-3">
                            <x-input-label for="feed_update" :value="__('Update Feed')" />
                            <x-text-input id="feed_update" name="feed_update" type="datetime-local"
                                class="mt-1 block w-full" :value="old('feed_update')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('feed_update')" />
                        </div>

                        <x-primary-button>{{ __('Adaugă') }}</x-primary-button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    {{-- </x-app-layout> --}}
@endsection
