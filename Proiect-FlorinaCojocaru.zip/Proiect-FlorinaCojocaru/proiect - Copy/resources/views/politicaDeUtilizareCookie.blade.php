@extends('layouts.app')
@section('content')
    <h2 style="text-align:justify; margin: 30px;"><b>Politica de utilizare cookie-uri</b></h2>
    <div
        class="relative sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-gray-100 dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
        <p style="text-align:justify; margin: 30px;"><b>Cine suntem?<br>
                Adresa noastră web este: https://frax.ro.</b></p>

        <p style="text-align:justify; margin: 30px;"><b>1. Politica de utilizare cookie-uri și tehnologii
                similare</b><br>
            Această politică se referă la cookie-urile și la tehnologiile similare folosite, după caz, în website-urile
            și
            aplicațiile operate de S.C. FRĂȚILĂ MARKETING ON-LINE S.R.L. cu sediul social în sat Sohodol, oraș Tismana,
            strada
            Grîul Bureților, nr. 12, județ Gorj, România, (denumită în continuare Frax.ro).</p>

        <p style="text-align:justify; margin: 30px;">Cookie-urile sunt folosite pentru următoarele scopuri:</p>

        <p style="text-align:justify; margin: 30px;">• de funcționare a site-ului,<br>
            • de analiză a comportamentului vizitatorilor site-ului,<br>
            • pentru publicitate.<br>
            Această politică se completează cu politica Frax.ro cu privire la protecția datelor personale în general pe
            care o
            puteți găsi aici și cu Termenii și Condițiile site-ului pe care le puteți găsi aici, pe care vă încurajăm să
            le
            citiți, acestea incluzând informații suplimentare utile, inclusiv cu privire la responsabilul Frax.ro pentru
            protecția datelor personale, toate scopurile prelucrărilor de date de către Frax.ro, drepturile
            dumneavoastră,
            precum și excepțiile și limitele acestora etc.</p>

        <p style="text-align:justify; margin: 30px;">Protecția corespunzătoare a datelor cu caracter personal este un
            obiectiv important pentru Frax.ro. Dorința
            noastră
            este să fim cât mai clari și transparenți cu privire la abordarea Frax.ro. Pentru orice întrebare, vă rugăm
            să ne
            contactați la support@frax.ro.</p>

        <p style="text-align:justify; margin: 30px;"><b>2. Ce sunt cookie-urile?</b><br>
            Cookie-ul este un fișier de mici dimensiuni, format din litere și numere, care va fi stocat pe computerul,
            terminalul mobil sau alte echipamente ale unui utilizator de pe care se accesează internetul. Cookie-ul este
            instalat prin solicitarea emisă de către terminalul utilizatorului către un server Frax.ro sau către un
            server al
            unei terțe părți.</p>

        <p style="text-align:justify; margin: 30px;"><b>3. La ce sunt folosite cookie-urile?</b><br>
            Aceste fișiere fac posibilă în principal recunoașterea terminalului utilizatorului și prezentarea
            conținutului
            într-un mod relevant, adaptat preferințelor utilizatorului.</p>

        <p style="text-align:justify; margin: 30px;">Cookie-urile asigură utilizatorilor o experiență plăcută de
            navigare și susțin eforturile Frax.ro pentru a
            oferi
            servicii mai adaptate utilizatorilor, ex: – preferințele în materie de confidențialitate online, coșul de
            cumpărături sau publicitate relevantă. De asemenea, sunt utilizate în pregătirea unor statistici anonime
            agregate
            care ne ajută să înțelegem cum un utilizator beneficiază de paginile noastre de internet, permițându-ne
            îmbunătățirea structurii și conținutului lor, fără a permite identificarea personală a utilizatorului.</p>

        <p style="text-align:justify; margin: 30px;"><b>4. Ce cookie-uri folosim?</b><br>
            Folosim două tipuri de cookie-uri: per sesiune și fixe. Cookie-urile per sesiune sunt fișiere temporare ce
            rămân în
            terminalul utilizatorului până la terminarea sesiunii sau închiderea aplicației. Cookie-urile fixe rămân pe
            terminalul utilizatorului pe o perioadă determinată de parametrii cookie-ului sau până sunt șterse manual de
            utilizator.</p>

        <p style="text-align:justify; margin: 30px;"><b>5. Cum sunt folosite cookie-urile de către acest site?</b><br>
            O vizită pe acest site poate plasa următoarele tipuri de cookie-uri:</p>

        <p style="text-align:justify; margin: 30px;">• cookie-uri strict necesare pentru funcționarea site-ului<br>
            • cookie-uri de analiză<br>
            • cookie-uri pentru publicitate<br>
            Cookie-urile și/sau tehnologiile similare strict necesare sunt esențiale pentru buna funcționare a
            site-ului, fiind
            setate pe dispozitivul dumneavoastră la accesarea site-ului sau în urma acțiunilor efectuate în site, după
            caz.
            Puteți seta browser-ul dumneavoastră pentru a bloca cookie-urile, însă în acest caz anumite secțiuni ale
            site-ului
            nu vor funcționa corect.</p>

        <p style="text-align:justify; margin: 30px;">Celelalte categorii de cookie-uri au rolul indicat la secțiunea 11.
        </p>

        <p style="text-align:justify; margin: 30px;"><b>6. Conțin cookie-urile sau tehnologiile similare date
                personale?</b><br>
            Cookie-urile sau tehnologiile similare în sine nu solicită informații cu caracter personal pentru a putea fi
            utilizate și, în multe cazuri, nici nu identifică personal utilizatorii de internet. Există însă situații
            când
            datele personale pot fi colectate prin utilizarea cookie-urilor pentru a facilita anumite funcționalități
            pentru
            utilizator sau pentru a oferi utilizatorului o experiență mai adaptată preferințelor sale. Astfel de date
            sunt
            criptate într-un mod care face imposibil accesul persoanelor neautorizate la ele.</p>

        <p style="text-align:justify; margin: 30px;">Ce sunt tehnologiile similare?<br>
            Există alte tehnologii care pot fi utilizate în aceleași scopuri precum cookie-urile.</p>

        <p style="text-align:justify; margin: 30px;">Frax.ro utilizează ca tehnologie similară Local Storage.</p>

        <p style="text-align:justify; margin: 30px;"><b>7. Blocare cookie-uri</b><br>
            În cazul în care doriți sa blocați cookie-urile, unele funcționalități ale site‑ului vor fi oprite, iar
            acest lucru
            poate genera anumite disfuncționalități sau erori în folosirea site-ului nostru. De exemplu, blocarea
            cookie-urilor
            vă poate împiedica să:</p>

        <p style="text-align:justify; margin: 30px;">• cumpărați online<br>
            • vă autentificați în contul dumneavoastră<br>
            În cazul în care ești de acord cu aceste limitări și dorești să blochezi cookie-urile, o poți face din
            setările
            browser-ului pe care îl folosești.</p>

        <p style="text-align:justify; margin: 30px;">Cele mai multe browsere sunt setate implicit să accepte cookie-uri,
            dar aveți posibilitatea să modificați
            setările
            pentru a bloca unele sau toate cookie-urile.</p>

        <p style="text-align:justify; margin: 30px;"><b>8. Administrarea preferințelor cu privire la plasarea de
                cookie-uri</b><br>
            În general, o aplicație folosită pentru accesarea paginilor web permite salvarea cookie-urilor și/sau a
            tehnologiilor similare pe terminal în mod implicit. Acestea sunt stocate pe perioade descrise în tabelul de
            la
            secțiunea 11 de mai jos. Aceste setări pot fi schimbate în așa fel încât administrarea automată a
            cookie-urilor să
            fie blocată de browser-ul web sau utilizatorul să fie informat de fiecare dată când cookie-uri sunt trimise
            către
            terminalul său.</p>

        <p style="text-align:justify; margin: 30px;">Informații detaliate despre posibilitățile și modurile de
            administrare a cookie-urilor pot fi găsite în zona
            de
            setări a aplicației (browser-ului web). Limitarea folosirii cookie-urilor poate afecta anumite
            funcționalități ale
            website-ului.</p>

        <p style="text-align:justify; margin: 30px;"><b>9. De ce sunt cookie-urile și/sau tehnologiile similare
                importante pentru Internet?</b><br>
            Cookie-urile și/sau tehnologiile similare reprezintă un punct central al funcționării eficiente a
            Internetului,
            ajutând la generarea unei experiențe de navigare prietenoase și adaptate preferințelor și intereselor
            fiecărui
            utilizator. Refuzarea sau dezactivarea cookie-urilor poate face unele site-uri sau părți ale site-urilor
            imposibil
            de folosit.</p>

        <p style="text-align:justify; margin: 30px;">Dezactivarea cookie-urilor nu înseamnă că nu veți mai primi, cu
            respectarea legislației, publicitate online –
            ci doar
            că aceasta nu va mai putea ține cont de preferințele și interesele dvs., evidențiate prin comportamentul de
            navigare.</p>

        <p style="text-align:justify; margin: 30px;">Exemple de întrebuințări importante ale cookie-urilor (care nu
            necesită autentificarea unui utilizator prin
            intermediul unui cont):</p>

        <p style="text-align:justify; margin: 30px;">• Conținut și servicii adaptate preferințelor utilizatorului –
            categorii de produse și servicii.<br>
            • Oferte adaptate intereselor utilizatorilor<br>
            • Reținerea parolelor<br>
            • Reținerea filtrelor de protecție a copiilor privind conținutul pe Internet (opțiuni family mode, funcții
            de safe
            search).<br>
            • Limitarea frecvenței de difuzare a reclamelor – limitarea numărului de afișări a unei reclame pentru un
            anumit
            utilizator pe un site.<br>
            • Furnizarea de publicitate relevantă pentru utilizator.<br>
            • Măsurarea, optimizarea și adaptarea caracteristicilor de analiză – cum ar fi confirmarea unui anumit nivel
            de
            trafic pe un website, ce tip de conținut este vizualizat și modul cum un utilizator ajunge pe un website
            (ex: prin
            motoare de căutare, direct, din alte website-uri etc.). Website-urile derulează aceste analize privitoare la
            utilizarea lor pentru a-și îmbunătăți serviciile în beneficiul utilizatorilor.</p>

        <p style="text-align:justify; margin: 30px;">
            <b>10. Securitate și aspecte legate de confidențialitate</b><br>
            În general browserele au integrate setări de confidențialitate care furnizează diferite niveluri de
            acceptare a
            cookie-urilor, perioada de valabilitate și ștergere automată după ce utilizatorul a vizitat un anumit site.
        </p>

        <p style="text-align:justify; margin: 30px;">Alte aspecte de securitate legate de cookie-uri:</p>

        <p style="text-align:justify; margin: 30px;">• Particularizarea setărilor browserului în ceea ce privește
            cookie-urile pentru a reflecta un nivel
            confortabil
            pentru dumneavoastră al securității utilizării cookie-urilor.<br>
            • Dacă sunteți singura persoană care utilizează computerul, puteți seta, dacă doriți, termene lungi de
            expirare
            pentru stocarea istoricului de navigare și a datelor personale de acces.<br>
            • Dacă împărțiți accesul la calculator, puteți lua în considerare setarea browserului pentru a șterge datele
            individuale de navigare de fiecare dată când închideți browserul. Aceasta este o variantă de a accesa
            site-urile
            care plasează cookie-uri și de a șterge orice informație de vizitare la închiderea sesiunii de navigare.</p>

        <p style="text-align:justify; margin: 30px;"><b>11. Linkuri și informații suplimentare utile</b></p>

        <p style="text-align:justify; margin: 30px;">Deoarece acest site este un catalog de comparare de produse,
            Frax.ro nu își vinde propriile produse, ci
            prezintă
            produsele altor furnizori. Toate link-urile de produse vă redirecționează către site-ul web al
            comerciantului.</p>

        <p style="text-align:justify; margin: 30px;">Făcând clic pe aceste linkuri, veți fi redirecționat(ă) direct
            către site-ul web al comerciantului, care
            conține
            propriile politici de confidențialitate.</p>

        <p style="text-align:justify; margin: 30px;">Colectarea și prelucrarea datelor cu caracter personal pe
            site-urile respective ale terților sunt
            responsabilitatea
            exclusivă a furnizorului de servicii respectiv. Frax.ro nu are nicio influență în acest sens și, prin
            urmare, nu
            este responsabil sau răspunzător pentru prelucrarea datelor.<br>
            Dacă doriți să aflați mai multe informații despre cookie-uri și la ce sunt utilizate, recomandăm următoarele
            linkuri:
            <br>
            - Microsoft Cookies guide<br>
            - All About Cookies
        </p>
        <p style="text-align:justify; margin: 30px;">Frax.ro folosește serviciile următoarelor terțe părți în scopul
            oferirii de funcționalități, pentru analiză
            și
            pentru publicitate. Este posibil ca aceste terțe părți să seteze și să folosească cookie-uri și/sau
            tehnologii
            similare pe website-urile și în aplicațiile operate de Frax.ro, precum și pe website-uri și în alte
            aplicații decât
            cele operate de Frax.ro.</p>

        <p style="text-align:justify; margin: 30px;">Pentru mai multe detalii, consultați politicile de protecție a
            datelor precum și ghidurile de administrare a
            preferințelor utilizatorilor și posibilitățile de dezactivare oferite de companiile care gestionează aceste
            servicii, după caz:</p>
        <table style="text-align:justify; margin: 30px;">
            <tr>
                <td>Denumire</td>
                <td>Categorie</td>
                <td>Scop</td>
                <td>Politici</td>
            </tr>

            <tr>
                <td>Google Analytics</td>
                <td>Analiză</td>
                <td>Web analytics</td>
                <td>
                    https://www.google.com/analytics/terms/gb.html,<br>
                    https://support.google.com/analytics/answer/6004245
                </td>
            </tr>

            <tr>
                <td>Google Ads</td>
                <td>Publicitate</td>
                <td>Remarketing</td>
                <td>https://policies.google.com/privacy,<br>
                    https://policies.google.com/technologies/ads
                </td>
            </tr>

            <tr>
                <td>Profitshare</td>
                <td>Publicitate</td>
                <td>Remarketing</td>
                <td>https://profitshare.ro/en/privacy-policy</td>
            </tr>

            <tr>
                <td>2Performant</td>
                <td>Publicitate</td>
                <td>Remarketing</td>
                <td>https://ro.2performant.com/cookies/</td>
            </tr>

            <tr>
                <td>Facebook</td>
                <td>Publicitate</td>
                <td>Remarketing</td>
                <td>https://www.facebook.com/privacy/explanation</td>
            </tr>

        </table>
        <br>
        <br>
    </div>
@endsection
