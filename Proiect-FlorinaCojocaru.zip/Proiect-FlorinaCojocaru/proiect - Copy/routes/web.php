<?php

use App\Http\Controllers\FeedController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ImageController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->name('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');


// Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::resource('/products', ProductController::class);
    Route::get('/products/list', [ProductController::class, 'list'])->name('products.list');

    Route::resource('/feeds', FeedController::class);
    
    
    Route::get('/contact', 'HomeController@index')->name('contact');
    Route::get('/favorite', 'HomeController@favorite')->name('favorite');
    Route::get('/compara', 'HomeController@compara')->name('compara');
    Route::get('/politicaDeConfidentialitate', 'HomeController@politicaDeConfidentialitate')->name('politicaDeConfidentialitate');
    Route::get('/termeniSiConditii', 'HomeController@termeniSiConditii')->name('termeniSiConditii');
    Route::get('/politicaDeUtilizareCookie', 'HomeController@politicaDeUtilizareCookie')->name('politicaDeUtilizareCookie');





//});

require __DIR__.'/auth.php';
