
<?php $__env->startSection('content'); ?>
    <h2 style="text-align:justify; margin: 30px;"><b>Contact</b></h2>

    <div
        class="relative sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-gray-100 dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">

        <p style="text-align:justify; margin: 30px;">Salut! Dacă ai o întrebare pe care vrei să ne-o adresezi, ne poți
            contacta prin
            intermediul uneia dintre
            modalitățile de mai jos și noi îți răspundem cât de repede putem:</p>

        <p style="text-align:justify; margin: 30px;"><b>Companie:</b></p>

        <p style="text-align:justify; margin: 30px;">S.C. FRĂȚILĂ MARKETING ON-LINE S.R.L.</p>

        <p style="text-align:justify; margin: 30px;"><b>Adresă:</b> Sat Sohodol, Oraș Tismana, Strada Grîul Bureților,
            Nr. 12, județ Gorj, Cod poștal: 217503,
            România
        </p>

        <p style="text-align:justify; margin: 30px;">CUI: RO39937120</p>

        <p style="text-align:justify; margin: 30px;">Registrul Comerțului: J18/814/01.10.2018</p>

        <p style="text-align:justify; margin: 30px;"><b>Telefon</b>*: +40 728 620 729</p>

        <p style="text-align:justify; margin: 30px;">*linie telefonică cu tarif normal</p>

        <p style="text-align:justify; margin: 30px;"><b>E-mail:</b> support@flashx.ro</p>

        <p style="text-align:justify; margin: 30px;">Program: Luni – Vineri: 09:00 – 18:00.</p>


        <p style="text-align:justify; margin: 30px;">La solicitările trimise prin e-mail sau formular de contact, vom
            răspunde într-un interval de 8-24 ore
            lucrătoare de luni până vineri, exceptând sărbătorile.</p>

        <p style="text-align:justify; margin: 30px;">Pentru detalii privind confidențialitatea și prelucrarea datelor cu
            caracter personal, accesați pagina:
            <b>Politica de Confidențialitate</b>.
        </p>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proiect\resources\views/contact.blade.php ENDPATH**/ ?>