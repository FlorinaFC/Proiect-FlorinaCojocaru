
<?php $__env->startSection('content'); ?>
    <h3 style="text-align:justify; margin: 30px;"><b>Politica de Confidențialitate</b></h3>
    <p style="text-align:justify; margin: 30px;"><b>Politică de Confidențialitate cu privire la prelucrarea datelor cu
            caracter
            personal</b></p>

    <div
        class="relative sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-gray-100 dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
        <p style="text-align:justify; margin: 30px;">Prezenta <b>NOTIFICARE CU PRIVIRE LA CONFIDENȚIALITATEA
                DATELOR</b>
            vă informează cu privire la prelucrarea datelor
            dvs. cu
            caracter personal și vă prezintă drepturile în legătură cu această prelucrare, în conformitate cu
            Regulamentul (UE)
            2016/679 al Parlamentului și Consiliului European (“Regulamentul general privind protecția datelor” sau
            “GDPR”),
            precum și cu orice altă legislație aplicabilă pe teritoriul României. Textul integral al GDPR poate fi
            consultat în
            limba romană aici.</p>

        <p style="text-align:justify; margin: 30px;">Prelucrarea datelor este reglementată atât de GDPR, cât și de legile
            românești în vigoare, în mod special:
        </p>

        <p style="text-align:justify; margin: 30px;">- Legea CXII din 2011 privind dreptul la autodeterminare
            informațională și libertatea informației<br>
            - Legea V din Codul Civil<br>
            - Legea XLVIII privind condițiile de bază și anumite restricții privind activitățile comerciale<br>
            - Legea CVIII din 2001 despre serviciile comerțului electronic și societatea informațională.<br>
            <br>
            <b>Cine suntem și cum ne puteți contacta</b>
        </p>

        <p style="text-align:justify; margin: 30px;">FRAX este denumirea comercială a S.C. FRĂȚILĂ MARKETING ON-LINE
            S.R.L., administratorul și proprietarul
            paginii
            www.frax.ro, persoană juridică de naționalitate română, având sediul social în sat Sohodol, oraș Tismana,
            strada
            Grîul Bureților, nr. 12, județ Gorj, România, cu număr de ordine în Registrul Comerțului J18/814/01.10.2018,
            cod
            unic de înregistrare fiscală RO39937120 (în continuare “Frax.ro” sau “noi”). În sensul legislației cu
            privire la
            protecția datelor, suntem operator atunci când prelucrăm datele dvs. cu caracter personal.</p>

        <p style="text-align:justify; margin: 30px;">Întrucât suntem întotdeauna deschiși să aflăm opiniile
            dumneavoastră, precum și să vă furnizăm orice
            informații
            suplimentare de care ați putea avea nevoie cu privire la prelucrarea datelor dvs., vă încurajăm să
            contactați
            Responsabilul Frax.ro cu protecția datelor la adresa de e-mail support@frax.ro.</p>

        <p style="text-align:justify; margin: 30px;">Prezenta Notificare cu privire la confidențialitatea datelor este
            permanent disponibilă pe pagina:
            https://frax.ro/politica-de-confidentialitate/.</p>

        <p style="text-align:justify; margin: 30px;">Modificarea prezentei Notificări cu privire la confidențialitatea
            datelor poate fi necesară, ca urmare a
            modificării
            legislației. În eventualitatea unei astfel de modificări vă vom notifica. Dacă modificările impun obținerea
            consimțământului dvs., Frax.ro vă poate cere din nou consimțământul pentru prelucrarea datelor.</p>

        <p style="text-align:justify; margin: 30px;"><b>ACTIVITĂȚI DE PRELUCRARE A DATELOR</b></p>

        <p style="text-align:justify; margin: 30px;"><b>Ce categorii de date cu caracter personal prelucrăm</b></p>

        <p style="text-align:justify; margin: 30px;">În general, colectăm datele dvs. cu caracter personal direct de la
            dumneavoastră, astfel încât aveți
            controlul asupra
            tipului de informație pe care ne-o oferiți. Anumite servicii Frax.ro de pe paginile de produs sunt
            disponibile și
            pot fi utilizate fără înregistrare, pe baza consimțământului dvs.. Cu titlul de exemplu, primim informații
            de la
            dvs. astfel: prin completarea Formularului de Contact, ne transmiteți adresa de e-mail, numele și prenumele,
            prin
            contactarea telefonică ne transmiteți numărul de telefon, prin contactarea prin e-mail, ne transmiteți
            adresa de
            e-mail și orice alte informații pe care dvs. alegeți să le adăugați în textul e-mail-ului.</p>

        <p style="text-align:justify; margin: 30px;">Datele cu caracter personal pe care le transmiteți vor fi
            prelucrate pentru a atinge scopul pentru care au
            fost
            colectate.</p>

        <p style="text-align:justify; margin: 30px;">Prin furnizarea datelor precizate anterior, vă exprimați
            consimțământul pentru prelucrarea datelor în vederea
            prestării anumitor servicii de către Frax.ro. Acest consimțământ poate fi retras oricând prin înaintarea
            unei
            solicitări către Frax.ro pentru ștergerea datelor personale și a adresei de email. Prelucrarea acestor date
            se
            efectuează în temeiul art. 6 alin. 1 lit. a) din GDPR (consimțământ).</p>

        <p style="text-align:justify; margin: 30px;">Adresa dvs. de email înregistrată pentru folosirea anumitor
            servicii Frax.ro este stocată timp de 6 luni de
            la data
            înregistrării. Ștergerea adresei de e-mail și implicit a numelui pot fi solicitate la adresa
            support@frax.ro.</p>

        <p style="text-align:justify; margin: 30px;"p>Ștergerea datelor va fi efectuată în termen de o (1) zi lucrătoare
            de către Frax.ro.</p>

        <p style="text-align:justify; margin: 30px;">Putem, de asemenea, să colectăm și să prelucrăm ulterior anumite
            informații cu privire la comportamentul dvs.
            în
            timpul vizitării site-ului nostru web pentru a vă personaliza experiența online și a vă pune la dispoziție
            oferte
            adaptate profilului dvs. Vă invităm să aflați mai multe detalii în acest sens prin consultarea secțiunii
            privitoare
            la scopurile prelucrării de mai jos.</p>

        <p style="text-align:justify; margin: 30px;">Pe site-ul nostru web putem stoca și colecta informații în
            cookie-uri și tehnologii similare, conform
            Politicii de
            cookie-uri.</p>

        <p style="text-align:justify; margin: 30px;">Nu colectăm și nu prelucrăm în alt mod date sensibile, incluse de
            Regulamentul general privind protecția
            datelor în
            categorii speciale de date cu caracter personal. De asemenea, nu dorim să colectăm sau să prelucrăm date ale
            minorilor care nu au împlinit vârsta de 16 ani.</p>

        <p style="text-align:justify; margin: 30px;"><b>Care sunt scopurile și temeiurile prelucrării</b></p>

        <p style="text-align:justify; margin: 30px;">Vom utiliza datele dvs. cu caracter personal în următoarele
            scopuri:</p>

        <p style="text-align:justify; margin: 30px;"><b>1. PRESTAREA SERVICIILOR Frax.ro ÎN BENEFICIUL DVS.</b></p>

        <p style="text-align:justify; margin: 30px;">Acest scop general poate include, după caz, asigurarea serviciilor
            de suport, inclusiv oferirea de răspunsuri
            la
            întrebările dvs. cu privire la serviciile Frax.ro sau ale partenerilor.</p>

        <p style="text-align:justify; margin: 30px;"><b>2. PRELUCRAREA DATELOR ÎN SCOP DE ANALIZĂ</b></p>

        <p style="text-align:justify; margin: 30px;">Ne dorim în permanență să vă oferim cea mai bună experiență pe
            site-ul nostru și pentru aceasta, putem
            colecta și
            utiliza anumite informații în legătură cu comportamentul dvs. de pe site. Date analitice, cum ar fi numărul
            și
            frecvența vizitatorilor site-ului Frax.ro sunt urmărite și auditate de furnizori externi independenți
            (Google
            Analytics). Acestor furnizori externi Frax.ro nu le transferă date personale. Frax.ro folosește setări
            asigurate de
            prestatori externi, care permit înregistrarea adreselor IP în format anonim.</p>

        <p style="text-align:justify; margin: 30px;"><b>3. PENTRU APĂRAREA INTERESELOR NOASTRE LEGITIME</b></p>

        <p style="text-align:justify; margin: 30px;">Pot exista situații în care vom folosi sau transmite informații
            pentru a ne proteja drepturile și
            activitatea.
            Acestea pot include:</p>

        <p style="text-align:justify; margin: 30px;">– Măsuri de protecție a site-ului web și a utilizatorilor față de
            atacuri cibernetice:</p>

        <p style="text-align:justify; margin: 30px;">– Măsuri de prevenire și detectare a tentativelor de fraudare,
            inclusiv transmiterea unor informații către
            autoritățile publice competente;</p>

        <p style="text-align:justify; margin: 30px;">– Măsuri de gestionare a diverselor altor riscuri.</p>

        <p style="text-align:justify; margin: 30px;">Temeiul general al acestor tipuri de prelucrări este interesul
            nostru legitim de a ne apăra activitatea,
            fiind
            înțeles că ne asigurăm că toate măsurile pe care le luăm garantează un echilibru între interesele noastre și
            drepturile și libertățile dvs. fundamentale.</p>

        <p style="text-align:justify; margin: 30px;"><b>Cât timp păstrăm datele dvs. cu caracter personal</b></p>

        <p style="text-align:justify; margin: 30px;"><b>TRANSFERUL DATELOR PERSONALE CĂTRE AUTORITĂȚI</b></p>

        <p style="text-align:justify; margin: 30px;">În cazul unei solicitări din partea instanțelor judecătorești sau
            al unei investigații ale autorităților,
            Frax.ro va
            putea furniza datele personale stocate de acesta și solicitate de instanța sau autoritatea în cauză, în
            temeiul
            articolului 6 aliniatul 1 lit. c) din GDPR, cu condiția ca instanța sau autoritatea să fi indicat exact
            temeiul
            legal al transferului de date. Transfer către autorități sau instanțe judecătorești – numai în cazul în care
            s-a
            specificat exact scopul solicitării datelor și categoriile de date solicitate – Frax.ro va furniza date doar
            în
            măsura și în limita absolut necesare îndeplinirii scopului specificat în solicitare. Anterior transmiterii
            datelor
            către o autoritate sau instanță judecătorească, Frax.ro se va asigura că sunt îndeplinite toate condițiile
            necesare
            pentru transmiterea datelor, iar în caz afirmativ, va onora solicitarea.</p>

        <p style="text-align:justify; margin: 30px;"><b>SECURITATEA DATELOR</b></p>

        <p style="text-align:justify; margin: 30px;">Dispozitivele informatice folosite de Frax.ro pentru prelucrarea
            datelor personale sunt selectate și
            gestionate
            astfel încât acestea:</p>

        <p style="text-align:justify; margin: 30px;">să permită accesul persoanelor autorizate (disponibilitate);<br>
            să asigure autenticitatea prelucrării (autenticitatea prelucrării datelor);<br>
            să permită confirmarea faptului că datele nu au fost modificate (integritatea datelor);<br>
            să fie protejate împotriva accesului neautorizat (confidențialitatea datelor).<br>
            Frax.ro asigură securitatea datelor personale prin implementarea de măsuri tehnice, organizatorice și
            structurale,
            care oferă un nivel de protecție adecvat împotriva riscurilor aferente stocării datelor, și pe durata
            prelucrării
            asigură:</p>

        <p style="text-align:justify; margin: 30px;">confidențialitatea: datele sunt protejate, putând fi accesate doar
            de cei autorizați;<br>
            integritate: asigură acuratețea și integritatea informațiilor și a metodei de prelucrare;<br>
            disponibilitate: în caz de nevoie, persoanele autorizate pot accesa efectiv informațiile necesare,
            dispozitivele
            fiind disponibile în acest scop.<br>
            Sistemul informatic și rețeaua Frax.ro sunt protejate contra atacurilor de fraudă cibernetică, spionajului,
            sabotajului, vandalismului, incendiilor și inundațiilor, precum și contra virusurilor, atacurilor
            informatice,
            inclusiv atacurile tip DoS (denial of service – întreruperea serviciilor).</p>

        <p style="text-align:justify; margin: 30px;">Frax.ro asigură securitatea sistemului prin măsuri și metode
            specifice la nivelul serverelor și al
            aplicațiilor.</p>

        <p style="text-align:justify; margin: 30px;">În cazul unui incident de securitate a datelor, Frax.ro va efectua
            toate demersurile prevăzute de GDPR și va
            coopera
            cu utilizatorul. Frax.ro declară că dispune de reguli adecvate pentru gestionarea incidentelor de securitate
            a
            datelor.</p>

        <p style="text-align:justify; margin: 30px;"><b>DREPTURILE PERSOANELOR VIZATE</b></p>

        <p style="text-align:justify; margin: 30px;">Puteți contacta oricând persoana responsabilă de protecția datelor,
            conform celor menționate mai sus, pentru
            a
            exercita următoarele drepturi:</p>

        <p style="text-align:justify; margin: 30px;"> - aveți dreptul de a solicita o copie a datelor prelucrate și
            puteți solicita informații despre prelucrarea
            datelor
            (drept la acces, articolul 15 din GDPR);<br>
            - aveți dreptul să solicitați corectarea datelor eronate sau completarea datelor incomplete (drept la
            rectificare,
            articolul 16 din GDPR);<br>
            - aveți dreptul să solicitați ștergerea datelor personale; în cazul în care datele dvs. au fost făcute
            publice,
            aveți
            dreptul ca cererea de ștergere să fie comunicată și celorlalți operatori de date personale (drept la
            ștergere,
            articolul 17 din GDPR);<br>
            - aveți dreptul să solicitați restricționarea prelucrării datelor (drept la restricționarea prelucrării,
            articolul
            18
            din GDPR, respectiv Legea Info);<br>
            - aveți dreptul să primiți în format structurat, de utilizare generală și interoperabil datele dvs.
            personale pe
            care
            le-ați furnizat operatorului și să solicitați transferul acestora către un alt operator de date (drept la
            portabilitatea datelor, articolul 20 din GDPR);<br>
            - aveți dreptul să vă opuneți prelucrării datelor (drept la opoziție, articolul 21 din GDPR);<br>
            în cazul prelucrărilor efectuate în temeiul consimțământului, aveți dreptul să vă retrageți oricând
            consimțământul
            pentru prelucrarea datelor. Retragerea consimțământului nu va influența legalitatea prelucrării datelor
            prelucrate
            până în acel moment. (drept la retragerea consimțământului, articolul 7 alin. (3) din GDPR);<br>
            - aveți dreptul să depuneți o plângere la autoritatea de supraveghere dacă considerați că prelucrarea
            datelor s-a
            realizat cu nerespectarea dispozițiilor legale (drept de a depune o plângere, articolul 77 din GDPR).<br>
            <br>
            <b>GESTIONAREA COOKIE-URILOR</b>
        </p>

        <p style="text-align:justify; margin: 30px;">Frax.ro foloseste „cookie-uri” pentru stocarea preferințelor
            vizitatorilor (de ex. ce pagini a deschis sau
            downloadat), respectiv pentru a personaliza modul în care apare pagina Frax.ro în conformitate cu browser-ul
            utilizat de vizitator sau de informațiile transmise de browser. Prin utilizarea paginii, vizitatorul acceptă
            plasarea de către Frax.ro de cookie-uri pe calculatorul său.</p>

        <p style="text-align:justify; margin: 30px;">Toate detaliile referitoare la cookie-uri, le găsiți pe pagina:
            <b>Politica de utilizare cookie-uri</b>.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proiect\resources\views/politicaDeConfidentialitate.blade.php ENDPATH**/ ?>