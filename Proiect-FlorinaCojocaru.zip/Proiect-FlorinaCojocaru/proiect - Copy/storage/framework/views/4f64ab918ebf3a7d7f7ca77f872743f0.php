
<?php $__env->startSection('content'); ?>
    <div class="py-12">
        <?php if(session()->has('success')): ?>
            <div class="text-center py-3 bg-green-400 rounded-sm mx-auto"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="relative overflow-x-auto">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    Feed ID
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Nume
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    URL
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Update
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $feeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <th scope="row"
                                        class="px-6 py-3 font-medium text-dark-900 whitespace-nowrap dark:text-black">
                                        <a href=<?php echo e(route('feeds.show', $feed->id)); ?>><?php echo e($feed->id); ?></a>
                                        

                                    </th>
                                    <td class="px-6 py-3 font-bold">
                                        <?php echo e($feed->feed_name); ?>

                                    </td>
                                    <td class="px-6 py-3">
                                        <?php echo e($feed->feed_url); ?>

                                    </td>
                                    <td class="px-6 py-3">
                                        <?php echo e($feed->feed_update); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proiect - Copy\resources\views/feed/index.blade.php ENDPATH**/ ?>