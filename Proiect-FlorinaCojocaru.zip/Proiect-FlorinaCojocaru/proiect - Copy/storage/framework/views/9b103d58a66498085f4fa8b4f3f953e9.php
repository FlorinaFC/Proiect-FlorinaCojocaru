
<?php $__env->startSection('content'); ?>
    <h2 style="text-align:justify; margin: 30px;"><b>Termeni și Condiții</b></h2>

    <div
        class="relative sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-gray-100 dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
        <p style="text-align:justify; margin: 30px;"><b>1. DISPOZIȚII INTRODUCTIVE</b></p>

        <p style="text-align:justify; margin: 30px;">Aceste condiții de utilizare guvernează drepturile și obligațiile
            reciproce între societatea comercială S.C.
            FRĂȚILĂ MARKETING ON-LINE S.R.L., (denumită în continuare „furnizor“), având sediul social în sat Sohodol,
            oraș Tismana, strada Grîul Bureților, nr. 12, județ Gorj, România, și alte persoane, utilizatorii
            serviciilor Frax.ro (denumite în continuare „utilizator“), obligații care decurg din încheierea contractelor
            de prestări de servicii („contract privind furnizarea de servicii“) încheiate prin intermediul site-ul web
            ale furnizorului, situat la adresa internet https://frax.ro (în continuare „site”), eventual prin
            intermediul Facebook. Acordul mai reglementează drepturile și obligațiile și alte raporturi juridice conexe
            care decurg din utilizarea serviciilor frax.ro.</p>

        <p style="text-align:justify; margin: 30px;">Furnizorul poate modifica sau completa condițiile de utilizare.
            Modificările vor intra în vigoare imediat
            după publicarea pe site-ul web.</p>

        <p style="text-align:justify; margin: 30px;">FRAX.RO nu este un magazin online și nu este responsabil pentru
            acuratețea informațiilor furnizate de
            parteneri, inclusiv prețurile, descrierile produselor, dimensiunile, disponibilitatea sau corectitudinea
            imaginilor. Înainte de fiecare achiziție, vă recomandăm să revizuiți datele de pe site-ul magazinului online
            la care ați fost redirecționat(ă) din FRAX.RO. Toate produsele oferite sunt supuse condițiilor stabilite de
            terți și FRAX.RO nu este responsabil pentru acestea.</p>

        <p style="text-align:justify; margin: 30px;"><b>2. CONȚINUTUL CONTRACTULUI DE FURNIZARE DE SERVICII</b></p>

        <p style="text-align:justify; margin: 30px;">Acești termeni guvernează accesul și utilizarea serviciilor FRAX.RO
            și servesc drept acord legal între dvs.
            și FRAX.RO. Accesând FRAX.RO și alte utilizări ale acestor servicii, confirmați că ați citit, ați înțeles și
            ați fost de acord cu acești termeni și condiții.</p>

        <p style="text-align:justify; margin: 30px;"><b>3. TERMENII DE SERVICIU</b></p>

        <p style="text-align:justify; margin: 30px;">Furnizorul nu trebuie să presteze serviciile în cazul în care
            prestarea acestora este împiedicată de probleme
            din partea clientului sau a unor terțe părți. Furnizorul de servicii nu trebuie să presteze serviciile în
            special în cazul unui deficit de furnizare a energiei electrice, defecțiuni în rețeaua de date, alte
            defecțiuni cauzate de terțe părți sau intervenții de forță majoră.</p>

        <p style="text-align:justify; margin: 30px;">Pe parcursul furnizării serviciilor pot apărea întreruperi
            intermitente, restricții temporare, întreruperea
            sau degradarea calității serviciilor.</p>

        <p style="text-align:justify; margin: 30px;"><b>4. UTILIZAREA SERVICIILOR</b></p>

        <p style="text-align:justify; margin: 30px;">Accesul la serviciu este destinat exclusiv utilizatorului.
            Utilizatorul nu este autorizat fără acordul
            prealabil scris al furnizorului să permită utilizarea serviciilor de către terțe persoane.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul nu poate utiliza mecanisme de service, instrumente,
            software-ul sau proceduri care au sau ar
            putea avea un impact negativ asupra funcționării echipamentelor furnizorului, securității internetului sau a
            altor utilizatori de internet.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul nu poate desfășura activități orientate spre
            împiedicarea sau restricționarea funcționării
            serverului furnizorului pe care acesta operează serviciile sau să efectueze alte atacuri la acest server sau
            să fie asistat în astfel de activități de terțe părți. În special serverul furnizorului pe care acesta
            operează serviciul nu poate fi încărcat cu solicitări automate.</p>

        <p style="text-align:justify; margin: 30px;"><b>5. ALTE DREPTURI ȘI OBLIGAȚII ALE PǍRȚILOR</b></p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul recunoaște faptul că programele de calculator care
            creează paginile web ale site-ului sunt
            protejate de drepturi de autor. Utilizatorul se angajează să nu desfășoare nici o activitate care ar putea
            permite fie utilizatorului fie unor terțe părți să intervină în mod ilegal sau să folosească programe de
            calculator pentru care executorul sau beneficiarul drepturilor de proprietate este furnizorul.</p>

        <p style="text-align:justify; margin: 30px;">În relația dintre furnizor si utilizator, furnizorul nu este
            obligat de coduri de conduită în sensul § 53a
            Alin. 1 din Codul Civil.</p>

        <p style="text-align:justify; margin: 30px;"><b>6. PROTECȚIA DATELOR CU CARACTER PERSONAL ȘI TRIMITEREA DE
                INFORMAȚII</b><br></p>
        <p style="text-align:justify; margin: 30px;">Motivul legal al prelucrării datelor dvs. personale este faptul că
            această prelucrare este necesară pentru a
            îndeplini contractul dintre dvs. și administrator sau pentru a pune în aplicare măsurile de către
            administrator înainte de a încheia un astfel de contract, în sensul articolului 6 alineatul (1) litera (b)
            din REGULAMENTUL (UE) 2016/679 AL PARLAMENTULUI EUROPEAN ȘI AL CONSILIULUI din 27 aprilie 2016 privind
            protecția persoanelor fizice în ceea ce privește prelucrarea datelor cu caracter personal și privind libera
            circulație a acestor date și de abrogare a Directivei 95/46/CE (Regulamentul general privind protecția
            datelor), denumit în continuare “regulamentul”.</p>

        <p style="text-align:justify; margin: 30px;">Scopul prelucrării datelor dvs. personale este de a îndeplini
            contractul dintre dvs. și administrator sau de
            a pune în aplicare acordurile de către administrator înainte de a încheia un astfel de contract.</p>

        <p style="text-align:justify; margin: 30px;">Administratorul nu are o decizie individuală automată cu privire la
            articolului 22 din regulament.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul are capacitatea de a da consimțământul necondiționat
            la transmiterea de informații și de
            comunicare comercială aferente serviciului, de la furnizor la adresa utilizatorului. În același timp,
            utilizatorul își poate retrage consimțământul în orice moment.</p>

        <p style="text-align:justify; margin: 30px;">Toate detaliile referitoare la protecția datelor cu caracter
            personal le găsiți pe pagina: Politica de
            Confidențialitate, care face parte integrantă din Termenii de utilizare.</p>

        <p style="text-align:justify; margin: 30px;"><b>7. FOLOSIREA COOKIE-URILOR</b></p>

        <p style="text-align:justify; margin: 30px;">Vezi Politica de utilizare Cookie-uri, care face parte din
            prezentul Document.</p>

        <p style="text-align:justify; margin: 30px;"><b>8. RETRAGEREA DIN CONTRACTUL DE FURNIZARE SERVICII</b></p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul care este consumator în conformitate cu § 52 alin. 3
            din Legea nr. 40/1964 Coll., Codul civil,
            ulterior modificat ( “Codul civil”), are dreptul, în conformitate cu § 53 alin. 8 litera. a) Codul civil, de
            a se retrage din contractul de furnizare servicii, prin trimiterea unei cereri de anulare a utilizării
            serviciilor, de la adresa de e-mail utilizată la încheierea prezentului contract.</p>

        <p style="text-align:justify; margin: 30px;"><b>9. BARA DE CĂUTARE</b></p>

        <p style="text-align:justify; margin: 30px;">Pentru o listă completă a rezultatelor, căutăm, după numele și
            descrierea produselor, prin milioane de oferte
            furnizate de către comercianți. Includem, totodată, în căutare și categoria sau caracteristicile produselor.
            Vom afișa rezultatele căutării de produs în funcție de relevanța rezultatului. Rezultatele căutării bazate
            pe numele produselor au o relevanță mai mare decât rezultatele bazate pe texte descriptive. Afișăm produsele
            unde, în numele ofertei, termenul căutat apare în lista pe o poziție mai bună decât la alte produse.</p>

        <p style="text-align:justify; margin: 30px;">Căutarea mai multor cuvinte poate duce la afișarea unor rezultate
            unde termenii nu apar unul lângă celălalt
            în oferta de produs. Căutările pot fi influențate, printre altele, de acele produse unde brand-ul poate fi
            asociat cu termeni generici. De exemplu, o căutare pentru “carte + numele autorului” poate afișa nu numai
            carti de la autorul respectiv, dar și acele produse care conțin numele autorului în textul descrierii.
            Această situație poate apărea dacă numele autorului are caracter descriptiv sau conține o abreviere.</p>

        <p style="text-align:justify; margin: 30px;">Dacă aveți întrebări cu privire la rezultatele căutării noastre,
            întâmpinați erori sau găsiți o încălcare a
            drepturilor de marcă înregistrată ca urmare a listării rezultatelor, vă rugăm să ne trimiteți un e-mail la
            adresa support@frax.ro.</p>

        <p style="text-align:justify; margin: 30px;"><b>10. UTILIZAREA PAGINILOR WEB</b></p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul sau altă persoană care utilizează site-ul recunoaște
            că, fără acordul prealabil scris al
            furnizorului nu are dreptul să utilizeze textul, elementele grafice sau alte elemente protejate situate pe
            site și protejate de drepturi de autor.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul este de acord să plaseze pe site numai conținut al
            cărui autor este, sau al cărui autor și-a dat
            utilizatorului acordul privind publicarea conținutului pe site. Utilizatorul declară că plasarea și
            publicarea conținutului nu afectează în mod ilegal drepturile de autor ale unor terțe părți sau alte
            drepturi și că nu sunt încălcate nici alte reglementări generale cu caracter obligatoriu.</p>

        <p style="text-align:justify; margin: 30px;">Furnizorul nu este responsabil, în sensul specificat în § 5 din
            Legea nr. 480/2004 Coll. privind anumite
            Servicii ale Societății Informaționale, și în conformitate cu această prevedere, pentru comportamentul
            utilizatorilor.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul nu are dreptul ca în procesul utilizării site-ului
            (serverului) furnizorului să folosească
            mecanisme, software sau alte proceduri care au sau ar putea avea un impact negativ asupra funcționării
            site-ului sau a serverului.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul este autorizat să introducă informații pe site-ul web.
            Mai precis este vorba de crearea de
            seturi (colaje), colecții, încărcarea de imagini, adăugarea de comentarii (denumite în continuare
            „contribuții“). Mesajele exprimă punctele de vedere ale autorilor și nu reprezintă punctul de vedere al
            Furnizorului. Furnizorul nu este responsabil pentru veridicitatea informațiilor conținute în contribuții și
            conformitatea acestor informații cu legea.</p>

        <p style="text-align:justify; margin: 30px;">Furnizorul are dreptul de a elimina orice contribuție, fără
            justificare.</p>

        <p style="text-align:justify; margin: 30px;">Contribuțiile devin proprietatea Furnizorului la adăugarea acestora
            pe site, iar autorul acestora transferă
            furnizorului drepturile de autor asupra acestor contribuții, chiar dacă îi aparțin conform Legii nr.
            121/2000 MO, privind drepturile de autor și anume: de a utiliza, modifica, copia, distribui, prezenta, afișa
            public, prezenta public, reproduce, tipări, sublicenția, transfera sau vinde orice astfel de comunicare și
            de a crea lucrări derivate, sublicențiere către terți a dreptului de a aplica fără restricții oricare
            drepturi anterioare acordate în legătură cu aceste contribuții.</p>

        <p style="text-align:justify; margin: 30px;">Prin inserarea contribuției, utilizatorul renunță la orice drept de
            recompensă și declară că nu va
            restricționa modul de utilizare a contribuției inserate.</p>

        <p style="text-align:justify; margin: 30px;">Utilizatorul nu are drept la nici o compensație pentru inserarea
            contribuției.</p>

        <p style="text-align:justify; margin: 30px;">Furnizorul are dreptul de a acorda drept de utilizare (exclusiv sau
            neexclusiv) a contribuției unei terțe
            părți.</p>

        <p style="text-align:justify; margin: 30px;"><b>11. CONTACT</b></p>

        <p style="text-align:justify; margin: 30px;">Ne puteți contacta pentru orice neclaritate prin una dintre
            metodele afișate în pagina de Contact sau prin
            Formularul de contact.</p>

        <p style="text-align:justify; margin: 30px;"><b>12. DISPOZIȚII FINALE</b></p>

        <p style="text-align:justify; margin: 30px;">În cazul în care relația legată de utilizarea site-ul Web sau
            relația juridică legată prin contractul de
            servicii include un element internațional (străin), atunci părțile sunt de acord că relația este
            reglementată de dreptul român.</p>

        <p style="text-align:justify; margin: 30px;">Contractul de servicii, inclusiv termenii și condițiile este
            arhivat de furnizor în format electronic și nu
            este accesibil publicului.</p>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proiect - Copy\resources\views/termeniSiConditii.blade.php ENDPATH**/ ?>